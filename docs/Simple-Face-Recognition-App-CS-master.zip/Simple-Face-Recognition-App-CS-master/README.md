# Simple Face Recognition Application using C# and Emgu.CV 
Simple Face Recognition App CS
To use this solution , you need to restore the Nuget Packages first
1. Goto Solution Explorer and Right Click, 
2. Click on "Restore NuGet Packages"
3. Build as x64 Platform
4. Run the application


